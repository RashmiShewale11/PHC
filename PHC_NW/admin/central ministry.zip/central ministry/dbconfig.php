
<?php
//Database credentials
$dbHost     = 'localhost';
$dbUsername = 'root';
$dbPassword = 'komal123';
$dbName     = 'sih';

//Connect and select the database
$connect = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
}
?>
