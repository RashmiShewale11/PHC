<html>
<body>
	<?php
	$phc_id  = $_GET['id'];

	$conn = mysqli_connect("localhost","root","","file_upload");
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 		
	$sql = "SELECT * FROM  userfiles where phc_id = ".$phc_id;
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		$row = $result->fetch_assoc();
	}
	$name = $row["FileName"];
	$path = $row["FilePath"];
	$type = $row["FileType"];
	
	header('Content-type: "' . $type . '"');
    header('Content-Disposition: inline; filename="' . $name . '"');
    header('Content-Transfer-Encoding: binary');
    @readfile($path);

	mysqli_close($conn);
	?>
	
</body>
</html>
