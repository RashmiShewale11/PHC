<html>
   <body>
      
      <form action = "receive.php" method = "POST" enctype = "multipart/form-data">
         <input type = "file" name = "anyfile" />
         Phc Id : <input type="textbox" name="phc_id" />
         <input type = "submit" name="btnSubmit" />			
      </form>
      
   </body>
</html>