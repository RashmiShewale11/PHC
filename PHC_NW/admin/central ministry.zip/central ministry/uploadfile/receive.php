<html>
<body>
	<?php if(isset($_POST["btnSubmit"])) { ?>
		<ul> 
			<li>File size: <?php echo $_FILES['anyfile']['size'];  ?>
			<li>File type: <?php echo $_FILES['anyfile']['type'] ?>
			<li>Sent file: <?php echo $_FILES['anyfile']['name'];  ?>
		</ul>
		<?php 
		$conn = mysqli_connect("localhost","root","","file_upload");
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}

		$uploadThisFile = true;
		$errors= array();

		$bytes = 1024;
		$allowedKB = 200;
		$totalBytes = $allowedKB * $bytes;

		$file_name = $_FILES['anyfile']['name'];
		$file_size = $_FILES['anyfile']['size'];
		$file_tmp = $_FILES['anyfile']['tmp_name'];
		$file_type = $_FILES['anyfile']['type'];
		$file_ext=pathinfo($file_name,PATHINFO_EXTENSION);
		$phc_id=$_POST["phc_id"];
		$folder="phc_files";

		$extensions= array("jpeg","jpg","png","xls","pdf","doc");

		if(in_array($file_ext,$extensions) === false){
			$errors[]="extension not allowed, please choose a specified file.";
		}

		if($file_size > $totalBytes){
			$errors[]='File size must be below specified size';
		}

		if(empty($errors)==true){
			if(move_uploaded_file($file_tmp,"$folder/".$file_name)){

				$query = "INSERT INTO userfiles(FilePath,FileName,phc_id,FileType) VALUES('$folder/$file_name','$file_name','$phc_id','$file_type')";
				mysqli_query($conn, $query);
				?>
				<script>
					alert('Successfully Uploaded');
					window.location.href='view.php?success';
				</script>
				<?php
			}
		}else{
			?>
			<script>
				alert('error while uploading file');
				window.location.href='view.php?error=<?php echo $errors ?>';
			</script>
			<?php
		}
		mysqli_close($conn);
	} ?>

</body>
</html>