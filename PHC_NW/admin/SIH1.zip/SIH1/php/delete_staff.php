<?php

$dbHost = "localhost";
$dbUsername = "root";
$dbPassword = "shivani";
$dbName = "sih";

$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

if ($db->connect_error)
    die("Connection Failed..." . $db->connect_error);

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    echo $id;

    $delete_query = $db->query("delete from staff_details where staff_id='$id'");
    if ($delete_query) {
        header("Location: /staff.php");
        exit();
    } else {
        echo '<script>alert("Problem Deleting Data Data")</script>';
    }
}
?>