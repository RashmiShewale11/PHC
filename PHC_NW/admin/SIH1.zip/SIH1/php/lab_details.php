<?php
/**
 * Created by IntelliJ IDEA.
 * User: shivani
 * Date: 22/2/19
 * Time: 11:24 PM
 */

$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = 'shivani';
$dbName = 'sih';

$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

if ($db->connect_error)
    die("Connection Failed .." . $db->connect_error);

if (isset($_POST['sub1'])) {

    $urine_routine = $_POST['urine_routine'];
    $blood_tests = $_POST['blood_tests'];
    $diagnosis = $_POST['diagnosis'];
    $sputum = $_POST['sputum'];
    $maleria = $_POST['maleria'];
    $rapid_pregancy = $_POST['rapid_pregancy'];
    $rapid_hiv = $_POST['rapid_hiv'];

    $result = $db->query("select * from lab_services where PHCid=1");

    if ($result->num_rows >0) {
        $update_query = $db->query("update lab_services set urine_routine='$urine_routine',blood_tests='$blood_tests',diagnosis_RTI_STD='$diagnosis',sputum_testing='$sputum',malaria_exam='$maleria',rapid_pregnancy_test='$rapid_pregancy',rapid_HIV_test='$rapid_hiv' where PHCid=1");
        echo "<script>alert('Inserted Successfully')</script>";
        header("Location: /facilities.php");
        exit();

    } else {
        $insert_query = $db->query("insert into lab_services values ('1','$urine_routine','$blood_tests','$diagnosis','$sputum','$maleria','$rapid_pregancy','$rapid_hiv')");

        if ($insert_query) {

            echo "<script>alert('Inserted Successfully')</script>";
            header("Location: /facilities.php");
            exit();
        } else
            echo '<script>alert("Problem Inserting Data")</script>';
    }
}

$db->close();
?>