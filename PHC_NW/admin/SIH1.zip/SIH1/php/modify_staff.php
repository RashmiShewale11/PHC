<?php
/**
 * Created by IntelliJ IDEA.
 * User: shivani
 * Date: 22/2/19
 * Time: 11:24 PM
 */

$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = 'shivani';
$dbName = 'sih';

$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
session_start();

if ($db->connect_error)
    die("Connection Failed .." . $db->connect_error);

if (isset($_POST['sub1'])) {
    $id = mysqli_real_escape_string($db, $_POST['staff_id']);
    $name = mysqli_real_escape_string($db, $_POST['mstaff_name']);
    $email = mysqli_real_escape_string($db, $_POST['mstaff_email']);
    $contact = mysqli_real_escape_string($db, $_POST['mstaff_mob']);
    $gender = $_POST['mstaff_gender'];

    echo $name;
    $update_query = $db->query("update staff_details set name='$name', email_id='$email', contact_no='$contact', gender='$gender' where staff_id='$id'");
    //$_SESSION["err_designation"] = "";
    if ($update_query) {
        echo "<script>alert('Updated Successfully')</script>";
        header("Location: /staff.php");
        exit();
    } else
        echo '<script>alert("Problem Inserting Data")</script>';

}

$db->close();
?>